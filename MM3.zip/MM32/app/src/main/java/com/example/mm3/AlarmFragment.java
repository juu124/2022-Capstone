package com.example.mm3;

import static android.content.Context.ALARM_SERVICE;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;

import androidx.annotation.RequiresApi;
import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TimePicker;
import android.widget.Toast;

import java.net.Socket;
import java.net.URISyntaxException;
import java.nio.channels.DatagramChannel;
import java.util.Calendar;
import java.util.Random;

/**
 * A simple {@link Fragment} subclass.
 * Use the {@link AlarmFragment#newInstance} factory method to
 * create an instance of this fragment.
 */
public class AlarmFragment extends Fragment {


    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";

    // TODO: Rename and change types of parameters
    private String mParam1;
    private String mParam2;

    public AlarmFragment() {
        // Required empty public constructor
    }

    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *
     * @param param1 Parameter 1.
     * @param param2 Parameter 2.
     * @return A new instance of fragment AlarmFragment.
     */
    // TODO: Rename and change types and number of parameters
    public static AlarmFragment newInstance(String param1, String param2) {
        AlarmFragment fragment = new AlarmFragment();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }


    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }
    }


    AlarmManager alarmManager;
    PendingIntent pendingIntent;

    public TimePicker timePicker;
    Button set_save_bt;
    ListViewAdapter adapter;
    ListView listView;


    @RequiresApi(api = Build.VERSION_CODES.M)
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,

                             Bundle savedInstanceState) {

        //프래그먼트에서는 findViewID를 그냥 사용하지 못한다. 그래서 ViewGroup을 이용해서 findViewId를 사용할 수 있다.
        ViewGroup rootview = (ViewGroup) inflater.inflate(R.layout.fragment_alarm, container, false);

        
        
        //알람매니저 설정
        alarmManager = (AlarmManager) getActivity().getSystemService(ALARM_SERVICE);


        // Calendar 객체 생성
        Calendar calendar = Calendar.getInstance();

        // 알람리시버 intent 생성
        Intent my_intent = new Intent(getActivity(), AlarmReceiver.class);

        listView = (ListView) rootview.findViewById(R.id.listView);
        adapter = new ListViewAdapter();
        listView.setAdapter(adapter);
        timePicker = (TimePicker) rootview.findViewById(R.id.time_picker);
        set_save_bt = (Button) rootview.findViewById(R.id.set_save_bt);

        set_save_bt.setOnClickListener(new View.OnClickListener() {
            @RequiresApi(api = Build.VERSION_CODES.M)
            @Override
            public void onClick(View v) {
                String ampm;
                switch (v.getId()) {
                    case R.id.set_save_bt: {

                        if (timePicker.getHour() > 11 && timePicker.getHour() < 24) {
                            ampm = "오후";
                        } else ampm = "오전";
                        adapter.addItem(timePicker.getHour() + "", timePicker.getMinute() + "", ampm);
                        adapter.notifyDataSetChanged();//ㄹㅣ스트추가
                        // calendar에 시간 셋팅
                        calendar.set(Calendar.HOUR_OF_DAY, timePicker.getHour());
                        calendar.set(Calendar.MINUTE, timePicker.getMinute());

                        // 시간 가져옴
                        int hour = timePicker.getHour();
                        int minute = timePicker.getMinute();
                        Toast.makeText(getActivity(), "Alarm 예정 " + hour + "시 " + minute + "분", Toast.LENGTH_SHORT).show();

                        Random random = new Random();
                        int randomV = random.nextInt();


                        pendingIntent = PendingIntent.getBroadcast(getActivity(), randomV, my_intent,
                                PendingIntent.FLAG_UPDATE_CURRENT);

                        // 알람셋팅
                        alarmManager.set(AlarmManager.RTC_WAKEUP, calendar.getTimeInMillis(), pendingIntent);
                        break;
                    }
                }


            }
        });
        return rootview;
    }




}