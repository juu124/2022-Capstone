package com.example.mm3;

public class StringRequest {
}
